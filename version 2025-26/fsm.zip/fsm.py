#!/usr/bin/env python
# encoding: utf-8

# ejemplo de máquina de estados finitos
# para reconocer cadenas aritméticas
# como
#   12 + (a * 34 /(56 + pi))
#   1/(alfa-1)/beta/(1-gamma)
#
# pero no
#   e**(2*pi)
#   -1 + -2
#   sin(x)

#
# funciones
#
def leer():
    global cadena, cadena_idx
    if cadena_idx < len(cadena):
        cadena_idx += 1
        return cadena[cadena_idx-1]
    return None

#
# variables
#
cadena = "12 + (a * 34 /(56 + pi))"
cadena_idx = 0
estado = 'INICIO'

# locales
t = tt = txt = ""
puntos = anidacion = 0

#
# main
#
while True:
    # estado 1
    if estado == 'INICIO':
        cadena = cadena.replace(" ", "")
        cadena_idx = 0
        anidacion = 0
        estado = 'BASE'

    # estado 2
    elif estado == 'FIN':
        if anidacion > 0:
            print("FIN error! abre más paréntesis de los que cierra")
            exit(-1)
        break

    # estado 3
    elif estado == 'BASE':
        txt = ""
        puntos = 0
        tt = t
        t = leer()
        if t is None:
            estado = 'FIN'
        elif t in 'abcdefghijklmnopqrstubwxyz':
            txt = t
            estado = 'L_VARIABLE'
        elif t in '0123456789':
            txt = t
            estado = 'L_NUMERO'
        elif t == '.':
            txt = t
            puntos = 1
            estado = 'L_NUMERO'
        elif t == '(':
            print(t)
            anidacion += 1
        elif t == ')':
            print(t)
            anidacion -= 1
            if anidacion < 0:
                print("BASE error! cierra más paréntesis de los que abre")
                exit(-1)
        elif t in '+-*/' and tt == ')':
            print(t)
        else:
            print("BASE error! no puede '%s' en este momento" % t)
            exit(-1)

    # estado 4
    elif estado == 'L_VARIABLE':
        tt = t
        t = leer()
        if t is None:
            estado = 'FIN'
        elif t in 'abcdefghijklmnopqrstubwxyz':
            txt += t
        elif t in '+-*/':
            print(txt)
            print(t)
            estado = 'BASE'
        elif t == ')':
            print(txt)
            print(t)
            anidacion -= 1
            if anidacion < 0:
                print("L_VARIABLE error! cierra más paréntesis de los que abre")
                exit(-1)
            estado = 'BASE'
        else:
            print("L_VARIABLE error! no puede '%s' después de '%s'" % (t, txt))
            exit(-1)

    # estado 5
    elif estado == 'L_NUMERO':
        tt = t
        t = leer()
        if t is None:
            estado = 'FIN'
        elif t in '0123456789':
            txt += t
        elif t == '.':
            txt += t
            puntos += 1
            if puntos > 1:
                print("L_NUMERO error! punto decimal extra en '%s'" % txt)
                exit(-1)
        elif t in '+-*/':
            print(txt)
            print(t)
            estado = 'BASE'
        elif t == ')':
            print(txt)
            print(t)
            anidacion -= 1
            if anidacion < 0:
                print("L_NUMERO error! cierra más paréntesis de los que abre")
                exit(-1)
            estado = 'BASE'
        else:
            print("L_NUMERO error! no puede '%s' después de '%s'" % (t, txt))
            exit(-1)

